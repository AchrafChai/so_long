/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_map_utils_bonus.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: acchairo <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/02/24 17:41:06 by acchairo          #+#    #+#             */
/*   Updated: 2025/03/20 20:50:41 by acchairo         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "so_long_bonus.h"

void	ft_map_init(t_gg *gg)
{
	(*gg).height = 0;
	(*gg).width = 0;
	(*gg).coin = 0;
	(*gg).player = 0;
	(*gg).px = 0;
	(*gg).py = 0;
	(*gg).move = 0;
	(*gg).door = 0;
	(*gg).enemy = 0;
	(*gg).i = 0;
	(*gg).map = NULL;
	(*gg).mlx = NULL;
	(*gg).win = NULL;
	(*gg).x = 0;
	(*gg).y = 0;
	(*gg).img_1 = NULL;
	(*gg).img_0 = NULL;
	(*gg).img_e = NULL;
	(*gg).img_p = NULL;
	(*gg).img_c = NULL;
	(*gg).img_m1 = NULL;
	(*gg).img_m2 = NULL;
	(*gg).img_m3 = NULL;
	(*gg).img_m4 = NULL;
	(*gg).img_m5 = NULL;
}

void	ft_map_height_width(char *map, t_gg *gg)
{
	int		fd;
	char	*str;
	int		len;

	fd = ft_fd_get(map);
	str = get_next_line(fd);
	(*gg).width = ft_valid_strlen(str, gg);
	while (str)
	{
		len = ft_valid_strlen(str, gg);
		free(str);
		(*gg).height++;
		if ((*gg).width != len || len < 3 || (*gg).height > ((*gg).y / 32) - 2)
		{
			(*gg).width = 0;
			(*gg).height = 0;
			break ;
		}
		str = get_next_line(fd);
	}
	get_next_line(-1);
	if (fd != -1)
		close(fd);
}

void	ft_map_check_done(char *str, t_gg *gg)
{
	int	j;

	j = 0;
	while (str[j])
	{
		if (str[j] == 'P')
			(*gg).player++;
		else if (str[j] == 'E')
			(*gg).door++;
		else if (str[j] == 'C')
			(*gg).coin++;
		else if (str[j] == 'M')
			(*gg).enemy++;
		j++;
	}
}

int	ft_map_valid(char *str, t_gg gg, int i)
{
	int	j;

	j = 0;
	while (str[j])
	{
		if (i == 0 || i == (gg.height - 1) || j == 0 || j == gg.width - 1)
		{
			if (str[j] != '1')
				return (0);
		}
		else
		{
			if (str[j] != '0' && str[j] != '1' && str[j] != 'C'
				&& str[j] != 'E' && str[j] != 'P' && str[j] != 'M')
				return (0);
		}
		j++;
	}
	if (j != gg.width)
		return (0);
	return (1);
}

void	ft_map_free(t_gg *gg, int i)
{
	if ((*gg).map)
	{
		while (i != -1)
		{
			free((*gg).map[i]);
			i--;
		}
		free((*gg).map);
	}
}
